package com.example.ad_practicaregistro

import java.io.Serializable

data class Usuario (var id:String?=null,
                    var nombre:String?=null,
                    var contraseña:String?=null,
                    var tipo:String?="normal",
                    var url_imagen:String?=null,
                    val fecha:String?=null,
                    var horasVuelo:Int?=null,
                    var estado_noti:Int?=null,
                    var estado:Int?=null,
                    var nombreAnterior:String?=""):Serializable