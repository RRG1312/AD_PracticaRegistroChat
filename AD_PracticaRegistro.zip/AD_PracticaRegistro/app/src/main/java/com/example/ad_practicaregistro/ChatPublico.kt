package com.example.ad_practicaregistro

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class ChatPublico : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var lista:ArrayList<Mensaje>
    private lateinit var db_ref: DatabaseReference

    private lateinit var mensaje_enviado: EditText
    private lateinit var boton_enviar: Button
    lateinit var pojo_usuario:Usuario
    lateinit var SP:SharedPreferences

    var url_imagen=""
    var id_emisor=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_publico)
        pojo_usuario=intent.getSerializableExtra("usuario") as Usuario
        db_ref= FirebaseDatabase.getInstance().getReference()
        lista=ArrayList<Mensaje>()
        mensaje_enviado=findViewById(R.id.et_enviar_chat)
        boton_enviar=findViewById(R.id.bt_enviar_mensaje)

    }

    override fun onStart() {
        super.onStart()


        val app_id = R.string.app_name
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)

        var loged = SP.getString(
            R.string.sp_nombre_usuario.toString(),""
        )

        db_ref.child("hangar").child("pilotos")
            .orderByChild("id").equalTo(pojo_usuario.id.toString())
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val pojo_usuario=snapshot.children.iterator().next().getValue(Usuario::class.java)
                    url_imagen=pojo_usuario?.url_imagen!!
                    id_emisor=pojo_usuario?.id!!

                }
                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(applicationContext,"Error", Toast.LENGTH_SHORT).show()
                }

            })

        boton_enviar.setOnClickListener{

            val mensaje = mensaje_enviado.text.toString().trim()

            if (mensaje != "") {
                val hoy: Calendar = Calendar.getInstance()
                val formateador: SimpleDateFormat = SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
                val fecha_hora = formateador.format(hoy.getTime());

                val id_mensaje = db_ref.child("hangar").child("chatPublico").push().key!!
                val nuevo_mensaje =
                    Mensaje(id_mensaje, id_emisor, "", mensaje.toString(),
                        fecha_hora,url_imagen,loged)
                db_ref.child("hangar").child("chatPublico").child(id_mensaje)
                    .setValue(nuevo_mensaje)
                mensaje_enviado.setText("")
            } else {
                Toast.makeText(applicationContext, "Escribe algo", Toast.LENGTH_SHORT).show()
            }

        }

        db_ref.child("hangar").child("chatPublico").addChildEventListener(object: ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val pojo_mensaje=snapshot.getValue(Mensaje::class.java)
                pojo_mensaje!!.usuario_receptor=pojo_usuario.id.toString()
                lista.add(pojo_mensaje)
                recycler.adapter!!.notifyDataSetChanged()
                recycler.scrollToPosition(lista.size-1)
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {

            }

            override fun onChildRemoved(snapshot: DataSnapshot) {

            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {

            }

            override fun onCancelled(error: DatabaseError) {

            }
        })





        recycler=findViewById(R.id.rv_mensajes)
        recycler.adapter=AdaptadorMensajes(lista)
        recycler.layoutManager= LinearLayoutManager(applicationContext)
        recycler.setHasFixedSize(true)

    }
}