package com.example.ad_practicaregistro

class Estado {
    companion object{
        const val NOTIFICADO=0
        const val CREADO=1
        const val MODIFICADO=2
        const val MODIFICADO_NOMBRE=3
        const val MODIFICADO_DISP=4
    }
}