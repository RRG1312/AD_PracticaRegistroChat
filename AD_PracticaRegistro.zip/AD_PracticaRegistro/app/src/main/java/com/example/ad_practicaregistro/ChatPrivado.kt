package com.example.ad_practicaregistro

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class ChatPrivado : AppCompatActivity() {
    private lateinit var recycler: RecyclerView
    private lateinit var lista:ArrayList<MensajePrivado>
    private lateinit var db_ref: DatabaseReference
    private lateinit var nombre_usuario:String
    private lateinit var mensaje_enviado: EditText
    private lateinit var boton_enviar: Button
    //var pojo_usuario:Usuario?= Usuario()
    var pojo_usuarioAux:Usuario?=Usuario()
    lateinit var SP:SharedPreferences
    var id_emisor=""
    var url_imagen=""
    lateinit var rv:RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_privado)

        //pojo_usuario=intent.getSerializableExtra("usuario") as Usuario?:Usuario()
        db_ref= FirebaseDatabase.getInstance().getReference()
        lista=ArrayList<MensajePrivado>()
        mensaje_enviado=findViewById(R.id.et_enviar_chatPrivado)
        boton_enviar=findViewById(R.id.bt_enviar_mensajePrivado)
        rv = findViewById(R.id.rv_mensajesPrivados)

    }

    override fun onStart() {
        super.onStart()
        val app_id = R.string.app_name
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)


        val idReceptor=intent.getStringExtra("idReceptor")!!

        var loged = SP.getString(
            R.string.sp_nombre_usuario.toString(),""
        )
        var propioId= SP.getString(
            R.string.sp_id_usuario.toString(),
            ""
        )

        db_ref.child("hangar").child("pilotos")
            .orderByChild("id").equalTo(propioId.toString().trim())
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.hasChildren()) {
                        pojo_usuarioAux = snapshot.children.iterator().next()
                            .getValue(Usuario::class.java)?: Usuario()
                        url_imagen=pojo_usuarioAux?.url_imagen.toString()
                        id_emisor=pojo_usuarioAux?.id.toString()
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(
                        applicationContext,
                        "Error en el login",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })


        boton_enviar.setOnClickListener{
            val msj=mensaje_enviado.text.toString().trim()

            if(msj!=""){
                val hoy: Calendar = Calendar.getInstance()
                val formateador: SimpleDateFormat = SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
                val fecha_hora = formateador.format(hoy.getTime());

                val id_mensaje=db_ref.child("hangar").child("chatPrivado").push().key!!
                val idEmisorReceptor=idReceptor+"@"+id_emisor
                val nuevo_mensaje=MensajePrivado(id_mensaje,idEmisorReceptor,msj,fecha_hora,url_imagen,loged)
                db_ref.child("hangar").child("chatPrivado").child(id_mensaje).setValue(nuevo_mensaje)
                mensaje_enviado.setText("")
            }else{
                Toast.makeText(applicationContext, "El mensaje no puede estar vacío", Toast.LENGTH_SHORT).show()
            }
        }

        db_ref.child("hangar").child("chatPrivado").addChildEventListener(object: ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val pojo_mensaje=snapshot.getValue(MensajePrivado::class.java)
                if(pojo_mensaje!!.ids_emisor_receptor!!.split("@").contains(id_emisor) && pojo_mensaje!!.ids_emisor_receptor!!.split("@").contains(idReceptor)){
                    lista.add(pojo_mensaje)
                    rv.adapter=AdaptadorMensajesPrivados(lista)
                    rv.scrollToPosition(lista.size-1)
                }
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {

            }

            override fun onChildRemoved(snapshot: DataSnapshot) {

            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {

            }

            override fun onCancelled(error: DatabaseError) {

            }
        })

        rv.adapter=AdaptadorMensajesPrivados(lista)
        rv.layoutManager= LinearLayoutManager(applicationContext)
        rv.setHasFixedSize(true)
    }
}