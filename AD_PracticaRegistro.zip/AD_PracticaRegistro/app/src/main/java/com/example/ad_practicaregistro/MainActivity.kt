package com.example.ad_practicaregistro

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.Serializable
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {
    private lateinit var contexto: Context

    lateinit var SP: SharedPreferences

    lateinit var username:EditText
    lateinit var password:EditText
    lateinit var login:Button
    lateinit var createAccount:TextView
    var pojo_usuario:Usuario?= Usuario()

    private lateinit var generador: AtomicInteger

    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference

    var loged:String=""
    var tipo_user:String=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val app_id = R.string.app_name
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)
/*
        with(SP.edit()){
            putString(R.string.sp_nombre_usuario.toString(), "")
            putString(R.string.sp_tipo_usuario.toString(),"")
            putString(R.string.sp_id_usuario.toString(),"")
            commit()
        }*/
    }

    override fun onStart() {
        super.onStart()
        username=findViewById(R.id.main_et_username) as EditText
        password=findViewById(R.id.main_et_password)
        login=findViewById(R.id.main_btn_login)
        createAccount=findViewById(R.id.main_tv_createAccount)

        generador=AtomicInteger(0)
        crearCanalNotificaciones()



        loged = SP.getString(R.string.sp_nombre_usuario.toString(),/*R.string.sp_nombre_usuario_def.toString())*/"")?:""
        tipo_user =SP.getString(R.string.sp_tipo_usuario.toString(),R.string.sp_tipo_usuario_def.toString())?:""


        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        if(loged!="" ){
            username.setText(loged)?:"0"
        }else if(tipo_user=="admin"){

            //startActivity(Intent(applicationContext,VerUsuarios::class.java))
        }

        createAccount.setOnClickListener{
            val intent = Intent(this,Registro::class.java)
            startActivity(intent)
        }

        login.setOnClickListener {
            if (username.text.toString().trim() == "") {
                username.error = "Introduce un usuario"
            } else if (password.text.toString().trim() == "") {
                password.error = "Introduce la contraseña"
            } else {
                db_ref.child("hangar").child("pilotos")
                    .orderByChild("nombre").equalTo(username.text.toString().trim())
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            if (snapshot.hasChildren()) {
                                pojo_usuario = snapshot.children.iterator().next()
                                    .getValue(Usuario::class.java)
                                if (pojo_usuario?.contraseña.equals(
                                        password.text.toString().trim()
                                    )
                                ) {
                                    val intent:Intent
                                    if (pojo_usuario?.tipo == "normal") {
                                        intent = Intent(applicationContext, ModificarUsuario::class.java)
                                        intent.putExtra("usuario", pojo_usuario as Serializable)
                                    } else {
                                        intent = Intent(applicationContext, Modificar_admin::class.java)
                                        intent.putExtra("usuario", pojo_usuario as Serializable)
                                    }
                                    with(SP.edit()){
                                        putString(R.string.sp_nombre_usuario.toString(), pojo_usuario?.nombre.toString().trim())
                                        putString(R.string.sp_tipo_usuario.toString(),pojo_usuario?.tipo.toString())
                                        putString(R.string.sp_id_usuario.toString(),pojo_usuario?.id.toString())
                                        commit()
                                    }
                                    startActivity(intent)
                                } else {
                                    Toast.makeText(
                                        applicationContext,
                                        "Contraseña incorrecta",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else {
                                Toast.makeText(
                                    applicationContext,
                                    "No existe el usuario",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(
                                applicationContext,
                                "Error en el login",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    })
            }
        }
        db_ref.child("hangar").child("pilotos")
            .addChildEventListener(object : ChildEventListener {
                //Necesito conseguir que las SP esten vacias al volver a MAinActivity o o inicar la app
                var loged = SP.getString(R.string.sp_nombre_usuario.toString(),"")?:""
                var tipo_user =SP.getString(R.string.sp_tipo_usuario.toString(),R.string.sp_tipo_usuario_def.toString())

                override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {

                    var pojo_usuario_noti=snapshot.getValue(Usuario::class.java)
                    if(!pojo_usuario!!.id.equals(pojo_usuario_noti?.id) &&
                        pojo_usuario_noti!!.estado_noti==Estado.CREADO && loged!=""){
                        db_ref.child("hangar").child("pilotos").child(pojo_usuario_noti!!.id!!)
                            .child("estado_noti").setValue(Estado.NOTIFICADO)
                        generarNotificacion(generador.incrementAndGet(),pojo_usuario!!,
                            "Se ha creado el usuario "+pojo_usuario_noti!!.nombre,"Nuevos datos en la app",MainActivity::class.java)
                    }

                }

                override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                    var pojo_usuario_noti=snapshot.getValue(Usuario::class.java)
                    if(!pojo_usuario!!.id.equals(pojo_usuario_noti?.id) &&
                        pojo_usuario_noti!!.estado_noti==Estado.MODIFICADO && loged!="") {
                        generarNotificacion(
                            generador.incrementAndGet(),
                            pojo_usuario!!,
                            "Se ha modificado el usuario " + pojo_usuario_noti!!.nombre,
                            "Datos editados en la app",
                            MainActivity::class.java
                        )
                        db_ref.child("hangar").child("pilotos").child(pojo_usuario_noti!!.id!!)
                            .child("estado_noti").setValue(Estado.NOTIFICADO)

                    }else if(!pojo_usuario!!.id.equals(pojo_usuario_noti?.id) &&
                                pojo_usuario_noti!!.estado_noti==Estado.MODIFICADO_NOMBRE && loged!=""){
                        generarNotificacion(generador.incrementAndGet(),pojo_usuario_noti!!,
                            "El usuario que se llamaba "+pojo_usuario_noti.nombreAnterior+
                                    " ahora se llama "+pojo_usuario_noti!!.nombre,"Actualizacion de usuario en la app",MainActivity::class.java)
                        db_ref.child("hangar").child("pilotos").child(pojo_usuario_noti!!.id!!).child("estado_noti")
                            .setValue(Estado.NOTIFICADO)

                    }else if(!pojo_usuario!!.id.equals(pojo_usuario_noti?.id) &&
                                pojo_usuario_noti!!.estado_noti==Estado.MODIFICADO_DISP && loged!=""){
                            if(pojo_usuario_noti.estado==1){
                                generarNotificacion(generador.incrementAndGet(),pojo_usuario_noti!!,
                                    "El usuario "+pojo_usuario_noti.nombre+
                                            " ahora esta disponible para chtear","Actualizacion de usuario en la app",MainActivity::class.java)
                                db_ref.child("hangar").child("pilotos").child(pojo_usuario_noti!!.id!!).child("estado_noti")
                                    .setValue(Estado.NOTIFICADO)

                            }else{
                                generarNotificacion(generador.incrementAndGet(),pojo_usuario_noti!!,
                                    "El usuario "+pojo_usuario_noti.nombre+
                                            " ya no esta disponible para chatear","Actualizacion de usuario en la app",MainActivity::class.java)
                                db_ref.child("hangar").child("pilotos").child(pojo_usuario_noti!!.id!!).child("estado_noti")
                                    .setValue(Estado.NOTIFICADO)

                            }
                    }
                }

                override fun onChildRemoved(snapshot: DataSnapshot) {
                    val pojo_usuario_noti=snapshot.getValue(Usuario::class.java)
                    if(!pojo_usuario!!.id.equals(pojo_usuario_noti?.id) && loged!=""){
                        generarNotificacion(generador.incrementAndGet(),
                                            pojo_usuario_noti!!
                                 ,"Se ha borrado el usuario "+pojo_usuario_noti!!.nombre,
                                     "Datos borrados en la app",
                                            MainActivity::class.java)
                    }
                }

                override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {

                }

                override fun onCancelled(error: DatabaseError) {

                }
            })



    }

    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this,MainActivity::class.java))
    }


    private fun generarNotificacion(id_noti:Int,pojo:Serializable,contenido:String,titulo:String,destino:Class<*>) {
        val idcanal = getString(R.string.id_canal)
        val iconolargo = BitmapFactory.decodeResource(
            resources,
            R.drawable.icons8_enviado_24
        )
        val actividad = Intent(applicationContext,destino)
        actividad.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK )
        actividad.putExtra("usuario", pojo)
        val pendingIntent= PendingIntent.getActivity(this,0,actividad, PendingIntent.FLAG_UPDATE_CURRENT)

        val notification = NotificationCompat.Builder(this, idcanal)
            .setLargeIcon(iconolargo)
            .setSmallIcon(R.drawable.icons8_enviado_24)
            .setContentTitle(titulo)
            .setContentText(contenido)
            .setSubText("sistema de información")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        with(NotificationManagerCompat.from(this)){
            notify(id_noti,notification)
        }
    }

    private fun crearCanalNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nombre = getString(R.string.nombre_canal)
            val idcanal = getString(R.string.id_canal)
            val descripcion = getString(R.string.description_canal)
            val importancia = NotificationManager.IMPORTANCE_DEFAULT

            val channel = NotificationChannel(idcanal, nombre, importancia).apply {
                description = descripcion
            }

            val nm: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }
}