package com.example.ad_practicaregistro

import android.content.Intent
import android.content.SharedPreferences
import android.media.Image
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.view.isInvisible
import com.bumptech.glide.Glide
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.File
import java.io.Serializable
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.CountDownLatch

class ModificarUsuario : AppCompatActivity() {
    lateinit var imagen:ImageView
    lateinit var nombre:EditText
    lateinit var horasVuelo:EditText
    lateinit var contraseña:EditText
    lateinit var fecha:TextView
    lateinit var disponibilidad:TextView
    lateinit var btn_modificar:Button
    lateinit var btn_cambiarDisponibilidad:Button
    lateinit var btn_chatPublico:Button
    lateinit var btn_chatPrivados:Button
    lateinit var btn_desconectar:Button
    lateinit var btn_baja:Button

    private lateinit var pojo_usuario:Usuario

    private var url_imagen: Uri?=null
    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference

    lateinit var SP: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_modificar_usuario)
    }

    override fun onStart() {
        super.onStart()

        pojo_usuario=intent.getSerializableExtra("usuario") as Usuario

        imagen = findViewById(R.id.modificar_iv_imagen)
        nombre = findViewById(R.id.modificar_et_username)
        horasVuelo = findViewById(R.id.modificar_et_horasVuelo)
        contraseña = findViewById(R.id.modificar_et_password)
        fecha=findViewById(R.id.modificar_tv_fecha)
        disponibilidad=findViewById(R.id.modificar_tv_estado)
        btn_modificar = findViewById(R.id.modificar_btn_modificar)
        btn_cambiarDisponibilidad=findViewById(R.id.modificar_cambiarDisponibilidad)
        btn_chatPublico=findViewById(R.id.modificar_btn_chatPublico)
        btn_chatPrivados=findViewById(R.id.modificar_btn_chatPrivado)
        btn_desconectar=findViewById(R.id.modificar_btn_desconectar)
        btn_baja = findViewById(R.id.modificar_btn_darDeBaja)

        val app_id = R.string.app_name
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)

        var loged = SP.getString(R.string.sp_nombre_usuario.toString(),"")
        var tipo_user = SP.getString(R.string.sp_tipo_usuario.toString(),"")

        if(loged==""){
            val intent = Intent(applicationContext,MainActivity::class.java)
            this.startActivity(intent)
        }

        Glide.with(applicationContext).load(pojo_usuario.url_imagen).into(imagen)
        nombre.setText(pojo_usuario.nombre)
        contraseña.setText(pojo_usuario.contraseña)
        horasVuelo.setText(pojo_usuario.horasVuelo.toString())
        fecha.setText(pojo_usuario.fecha)
        disponibilidad.setText(pojo_usuario.estado.toString())

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        imagen.setOnClickListener{
            obtener_url.launch("image/*")
        }

        imagen.setOnLongClickListener{
            val ficheroFoto=crearFicheroImagen()
            url_imagen= FileProvider.getUriForFile(applicationContext,"com.example.ad_practicaregistro.fileprovider",ficheroFoto)
            getCamera.launch(url_imagen)

            return@setOnLongClickListener true
        }

        btn_modificar.setOnClickListener{
            if(nombre.text.toString().trim().equals("") ||
                horasVuelo.text.toString().trim().equals("") ||
                contraseña.text.toString().trim().equals("")) {

                Toast.makeText(applicationContext, "No puedes dejar datos vacios", Toast.LENGTH_SHORT).show()
            }else if(horasVuelo.text.toString().trim().toIntOrNull()==null || horasVuelo.text.toString().toInt()<=0){
                Toast.makeText(applicationContext, "Las horas de vuelo tienen que ser mas de 0", Toast.LENGTH_SHORT).show()
            }else{
                var url_imagen_firebase:String?=pojo_usuario.url_imagen
                //
                var estado:Int?=Estado.MODIFICADO
                GlobalScope.launch(Dispatchers.IO) {
                    if(!nombre.text.toString().trim().equals(pojo_usuario.nombre) && existe_usuario(nombre.text.toString().trim())){
                        tostadaCorrutina("El usuario ya existe en la base de datos")
                    }else{
                        if(url_imagen!=null){
                            url_imagen_firebase=editarImagen(pojo_usuario.id!!,url_imagen!!)
                        }
                        //
                        if(!nombre.text.toString().trim().equals(pojo_usuario.nombre)){
                            estado=Estado.MODIFICADO_NOMBRE
                        }

                        editarUsuario(pojo_usuario.id!!,
                            nombre.text.toString().trim(),
                            contraseña.text.toString().trim(),
                            pojo_usuario.tipo.toString(),
                            url_imagen_firebase!!,
                            pojo_usuario.fecha.toString(),
                            horasVuelo.text.toString().toInt(),
                            estado!!,
                            pojo_usuario.estado.toString().toInt(),

                        )

                        editarPojoUsuario()
                        pojo_usuario.url_imagen=url_imagen_firebase


                        if(tipo_user=="normal"){
                            val intent = Intent(applicationContext,ModificarUsuario::class.java)
                            intent.putExtra("usuario", pojo_usuario as Serializable)
                            startActivity(intent)
                        }else {
                            val intent = Intent(applicationContext, VerUsuarios::class.java)
                            startActivity(intent)
                        }

/*
                        if(tipo_user=="admin") {
                            tostadaCorrutina("Avion modificado")
                            val actividad = Intent(applicationContext, VerUsuarios::class.java)
                            startActivity(actividad)
                        }else{
                            recreate()
                        }*/
                    }
                }
            }
        }


        btn_cambiarDisponibilidad.setOnClickListener{
            var nuevo_estado:Int
            if(pojo_usuario.estado==0){
                nuevo_estado=1
            }else{
                nuevo_estado=0
            }
            pojo_usuario.estado=nuevo_estado

            editarUsuario(pojo_usuario.id!!,
                nombre.text.toString().trim(),
                contraseña.text.toString().trim(),
                pojo_usuario.tipo.toString(),
                pojo_usuario.url_imagen!!,
                pojo_usuario.fecha.toString(),
                horasVuelo.text.toString().toInt(),
                4,
                pojo_usuario.estado.toString().toInt(),

            )

            /*
            cambiarDisp(pojo_usuario.id!!)*/
            val intent = Intent(applicationContext,ModificarUsuario::class.java)
            intent.putExtra("usuario", pojo_usuario as Serializable)
            startActivity(intent)
        }

        if(tipo_user=="admin") {

            btn_chatPublico.isInvisible=true
            btn_chatPrivados.isInvisible=true

        }

        btn_chatPublico.setOnClickListener {
            if(pojo_usuario.estado==1) {
                val intent = Intent(applicationContext, ChatPublico::class.java)
                intent.putExtra("usuario", pojo_usuario as Serializable)
                startActivity(intent)
            }else{
                Toast.makeText(this, "Tienes que cambiar tu estado", Toast.LENGTH_SHORT).show()
            }
        }

        btn_chatPrivados.setOnClickListener {
            if(pojo_usuario.estado==1) {
                val intent = Intent(applicationContext, ElegirChatPrivado::class.java)
                intent.putExtra("usuario", pojo_usuario as Serializable)
                startActivity(intent)
            }else{
                Toast.makeText(this, "Tienes que cambiar tu estado", Toast.LENGTH_SHORT).show()
            }

        }


        btn_baja.setOnClickListener{
            sto_ref.child("hangar").child("fotos").child(pojo_usuario.id!!).delete()
            db_ref.child("hangar").child("pilotos").child(pojo_usuario.id!!).removeValue()

            Toast.makeText(applicationContext, "Ha borrado su cuenta", Toast.LENGTH_SHORT).show()
            with(SP.edit()){
                putString(R.string.sp_nombre_usuario.toString(), "")
                putString(R.string.sp_tipo_usuario.toString(),"")

                commit()
            }

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        btn_desconectar.setOnClickListener{
            with(SP.edit()){
                putString(R.string.sp_nombre_usuario.toString(), "")
                putString(R.string.sp_tipo_usuario.toString(),"")

                commit()
            }

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }


    }
    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this,MainActivity::class.java))
    }

    private fun existe_usuario(nombre:String):Boolean{
        var resultado:Boolean?=false

        val semaforo= CountDownLatch(1)
        db_ref.child("hangar")
            .child("pilotos")
            .orderByChild("nombre")
            .equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.getValue(Usuario::class.java)!=null){
                        resultado=true;
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        semaforo.await();

        return resultado!!;
    }

    val getCamera=registerForActivityResult(ActivityResultContracts.TakePicture()){
        if(it){
            imagen.setImageURI(url_imagen)

            Toast.makeText(applicationContext, "He hechado una foto", Toast.LENGTH_SHORT).show()
        }else{
            Toast.makeText(applicationContext, "No se ha hechado una foto", Toast.LENGTH_SHORT).show()
        }
    }

    private fun crearFicheroImagen(): File {
        val cal: Calendar?= Calendar.getInstance()
        val timeStamp:String?= SimpleDateFormat("yyyyMMdd_HHmmss").format(cal!!.time)
        val nombreFichero:String?="JPGE_"+timeStamp+"_"
        val carpetaDir: File?=applicationContext.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val ficheroImagen: File?= File.createTempFile(nombreFichero!!,".jpg",carpetaDir)

        return ficheroImagen!!
    }

    private suspend fun editarImagen(id:String,imagen:Uri):String{
        var url_imagen_firebase:Uri?=null

        url_imagen_firebase=sto_ref.child("hangar").child("fotos").child(id)
            .putFile(imagen).await().storage.downloadUrl.await()

        return url_imagen_firebase.toString()
    }

    private fun editarUsuario(id:String,nombre:String,contraseña:String,tipo:String,url_imagen:String,fecha:String,horasVuelo:Int,estadoNoti:Int,estado:Int){
        val nuevo_usuario= Usuario(
            id,
            nombre,
            contraseña,
            tipo,
            url_imagen,
            fecha,
            horasVuelo,
            estadoNoti,
            estado,
            pojo_usuario.nombre
        )
        db_ref.child("hangar").child("pilotos").child(id).setValue(nuevo_usuario)

    }
    private fun cambiarDisp(id:String){

        var nuevo_estado:Int
        if(pojo_usuario.estado==0){
            nuevo_estado=1
        }else{
            nuevo_estado=0
        }
        pojo_usuario.estado=nuevo_estado

        db_ref.child("hangar").child("pilotos").child(id).child("estado").setValue(nuevo_estado)
        /*
        val nuevo_usuario= Usuario(
            id,
            nombre,
            contraseña,
            tipo,
            url_imagen,
            fecha,
            horasVuelo,
            estadoNoti,
            nuevo_estado,
            pojo_usuario.nombre
        )
        db_ref.child("hangar").child("pilotos").child(id).setValue(nuevo_usuario)*/
    }

    private fun editarPojoUsuario(){
        pojo_usuario.nombre=nombre.text.toString().trim()
        pojo_usuario.contraseña=contraseña.text.toString().trim()
        pojo_usuario.horasVuelo=horasVuelo.text.toString().trim().toInt()
        pojo_usuario.url_imagen=url_imagen.toString()
        pojo_usuario.nombreAnterior=pojo_usuario.nombre
    }




    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri:Uri?->
        when (uri){
            null-> Toast.makeText(applicationContext,"No has seleccionado ninguna imagen", Toast.LENGTH_SHORT).show()
            else->{
                url_imagen=uri
                imagen.setImageURI(url_imagen)
                Toast.makeText(applicationContext,"Has seleccionado una nueva imagen", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(
                applicationContext,
                texto,
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}