package com.example.ad_practicaregistro

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.Serializable

class VerUsuarios : AppCompatActivity() {
    lateinit var rv:RecyclerView

    lateinit var SP: SharedPreferences
    lateinit var nombre:TextView
    lateinit var propiaCuenta:Button
    lateinit var chatPrivado:Button
    lateinit var chatPublico:Button

    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference

    private lateinit var pojo_usuario:Usuario


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ver_usuarios)
    }

    override fun onStart() {
        super.onStart()

        //var propioId=pojo_usuario.id
        pojo_usuario= Usuario()


        val app_id = R.string.app_name
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)

        var loged = SP.getString(
            R.string.sp_nombre_usuario.toString(),""
        )

        var tipo = SP.getString(
            R.string.sp_tipo_usuario.toString(),
            ""
        )

        var propioId= SP.getString(
            R.string.sp_id_usuario.toString(),
            ""
        )

        var lista = mutableListOf<Usuario>()

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        db_ref.child("hangar").child("pilotos")
            .orderByChild("id").equalTo(propioId.toString().trim())
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.hasChildren()) {
                        pojo_usuario = snapshot.children.iterator().next()
                            .getValue(Usuario::class.java)?: Usuario()
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(
                        applicationContext,
                        "Error en el login",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })


        if(loged=="" || tipo=="normal" || tipo==""){
            val intent = Intent(applicationContext,MainActivity::class.java)
            this.startActivity(intent)
        }
        nombre =findViewById(R.id.ver_usuario_nombre)
        nombre.setText(loged)

        propiaCuenta = findViewById(R.id.ver_usuarios_propiaCuenta)
        propiaCuenta.setOnClickListener{
            val intent = Intent(applicationContext,Modificar_admin::class.java)
            intent.putExtra("usuario", pojo_usuario as Serializable)
            this.startActivity(intent)
        }

        chatPrivado = findViewById(R.id.ver_usuariochatPrivado)
        /*chatPrivado.setOnClickListener{
            val intent = Intent(applicationContext, ElegirChatPrivado::class.java)
            intent.putExtra("usuario", pojo_usuario as Serializable)
            startActivity(intent)
        }*/
        chatPublico = findViewById(R.id.ver_usuario_chatPublico)
        /*chatPublico.setOnClickListener{
            val intent = Intent(applicationContext, ChatPublico::class.java)
            intent.putExtra("usuario", pojo_usuario as Serializable)
            startActivity(intent)
        }*/

        chatPublico.setOnClickListener {
            if(pojo_usuario.estado==1) {
                val intent = Intent(applicationContext, ChatPublico::class.java)
                intent.putExtra("usuario", pojo_usuario as Serializable)
                startActivity(intent)
            }else{
                Toast.makeText(this, "Tienes que cambiar tu estado", Toast.LENGTH_SHORT).show()
            }
        }

        chatPrivado.setOnClickListener {
            if(pojo_usuario.estado==1) {
                val intent = Intent(applicationContext, ElegirChatPrivado::class.java)
                intent.putExtra("usuario", pojo_usuario as Serializable)
                startActivity(intent)
            }else{
                Toast.makeText(this, "Tienes que cambiar tu estado", Toast.LENGTH_SHORT).show()
            }

        }

        db_ref.child("hangar")
            .child("pilotos")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->
                        val pojo_usuario=hijo?.getValue(Usuario::class.java)
                        if(pojo_usuario?.id!=propioId){
                            lista.add(pojo_usuario!!)
                        }
                    }
                    rv.adapter?.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        rv = findViewById(R.id.ver_usuarios_rv)
        rv.adapter=AdaptadorUsuarios(lista)
        rv.layoutManager= LinearLayoutManager(applicationContext)
        rv.setHasFixedSize(true)
    }
}