package com.example.ad_practicaregistro

import java.io.Serializable

data class MensajePrivado(
    var id: String? = null,
    var ids_emisor_receptor: String? = null,
    var contenido: String? = null,
    var fecha_hora: String? = null,
    var url_avatar: String? = null,
    var nombre_emisor: String?=null
) : Serializable