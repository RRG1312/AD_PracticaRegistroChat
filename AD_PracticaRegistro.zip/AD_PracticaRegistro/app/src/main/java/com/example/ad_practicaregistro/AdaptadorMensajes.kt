package com.example.ad_practicaregistro

import android.content.Context
import android.content.Intent
import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isInvisible
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.Serializable

class AdaptadorMensajes(private val lista_mensajes:List<Mensaje>) : RecyclerView.Adapter<AdaptadorMensajes.MensajeViewHolder>() {
    private lateinit var contexto: Context

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MensajeViewHolder {
        val vista_item =
            LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
        //Para poder hacer referencia al contexto de la aplicacion
        contexto = parent.context

        return MensajeViewHolder(vista_item)
    }

    override fun onBindViewHolder(holder: MensajeViewHolder, position: Int) {
        val item_actual = lista_mensajes[position]


        if(item_actual.usuario_emisor==item_actual.usuario_receptor){
            //ES MIO,ASIGNAR A LA DERECHA Y YO
            holder.emisor.text=""
            holder.hora_emisor.text=""
            holder.nombre_emisor.text=""
            holder.imagen_emisor.isInvisible=true

            Glide.with(contexto).load(item_actual.url_avatar).into(holder.imagen_receptor)
            holder.nombre_receptor.text="Yo"
            holder.hora_receptor.text=item_actual.fecha_hora
            holder.yo.text=item_actual.contenido

        }else{
            //ES DE OTRO ASIGNAR A LA IZQUIERDA Y NOMBRE
            holder.yo.text=""
            holder.hora_receptor.text=""
            holder.nombre_receptor.text=""
            holder.imagen_receptor.isInvisible=true

            Glide.with(contexto).load(item_actual.url_avatar).into(holder.imagen_emisor)
            holder.nombre_emisor.text=item_actual.nombre_emisor.toString()
            holder.hora_emisor.text=item_actual.fecha_hora
            holder.emisor.text=item_actual.contenido
        }




    }

    override fun getItemCount(): Int = lista_mensajes.size


    class MensajeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val yo: TextView = itemView.findViewById(R.id.yo)
        val emisor: TextView = itemView.findViewById(R.id.emisor)
        val nombre_emisor: TextView = itemView.findViewById(R.id.nombre_emisor)
        val nombre_receptor: TextView = itemView.findViewById(R.id.nombre_receptor)
        val hora_receptor: TextView = itemView.findViewById(R.id.hora_receptor)
        val hora_emisor: TextView = itemView.findViewById(R.id.hora_emisor)
        val imagen_emisor:ImageView = itemView.findViewById(R.id.imagen_emisor)
        val imagen_receptor :ImageView = itemView.findViewById(R.id.imagen_receptor)

    }
}