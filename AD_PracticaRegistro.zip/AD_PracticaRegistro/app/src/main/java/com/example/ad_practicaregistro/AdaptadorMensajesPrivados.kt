package com.example.ad_practicaregistro

import android.content.Context
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class AdaptadorMensajesPrivados(private val lista_mensajes:List<MensajePrivado>) : RecyclerView.Adapter<AdaptadorMensajesPrivados.MensajeViewHolder>() {
    private lateinit var contexto: Context
    lateinit var SP:SharedPreferences

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MensajeViewHolder {
        val vista_item =
            LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
        //Para poder hacer referencia al contexto de la aplicacion
        contexto = parent.context

        return MensajeViewHolder(vista_item)
    }

    override fun onBindViewHolder(holder: MensajeViewHolder, position: Int) {
        val item_actual = lista_mensajes[position]

        val app_id = R.string.app_name
        val sp_name = "${app_id}_practica"
        SP = contexto.getSharedPreferences(sp_name, 0)

        val n_usuario=SP.getString(
            contexto.getString(R.string.sp_nombre_usuario),
            ""
        )
        var propioId= SP.getString(
            R.string.sp_id_usuario.toString(),
            ""
        )

        var emisor_receptor = item_actual.ids_emisor_receptor?.split("@")
        var emisor = emisor_receptor!![0]


        if(emisor!=propioId){
            holder.foto_otro.isVisible=false
            holder.nombre_otro.isVisible=false
            holder.hora_otro.isVisible=false
            holder.mensaje_otro.isVisible=false
            holder.mensaje_yo.text=item_actual.contenido
            holder.nombre_yo.text="Yo"
            holder.hora_yo.text=item_actual.fecha_hora
            Glide.with(contexto).load(item_actual.url_avatar).into(holder.foto_yo)

        }else{
            holder.nombre_otro.text=item_actual.nombre_emisor
            holder.foto_yo.isVisible=false
            holder.nombre_yo.isVisible=false
            holder.hora_yo.isVisible=false
            holder.mensaje_yo.isVisible=false
            holder.mensaje_otro.text=item_actual.contenido
            holder.hora_otro.text=item_actual.fecha_hora
            Glide.with(contexto).load(item_actual.url_avatar).into(holder.foto_otro)
        }

    }

    override fun getItemCount(): Int = lista_mensajes.size


    class MensajeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nombre_yo=itemView.findViewById<TextView>(R.id.nombre_receptor)
        val nombre_otro=itemView.findViewById<TextView>(R.id.nombre_emisor)
        val foto_yo=itemView.findViewById<ImageView>(R.id.imagen_receptor)
        val foto_otro=itemView.findViewById<ImageView>(R.id.imagen_emisor)
        val hora_yo=itemView.findViewById<TextView>(R.id.hora_receptor)
        val hora_otro=itemView.findViewById<TextView>(R.id.hora_emisor)
        val mensaje_yo=itemView.findViewById<TextView>(R.id.yo)
        val mensaje_otro=itemView.findViewById<TextView>(R.id.emisor)
    }
}