package com.example.ad_practicaregistro

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.io.Serializable

class AdaptadorUsuarios(private val lista_usuarios:List<Usuario>) : RecyclerView.Adapter<AdaptadorUsuarios.UsuarioViewHolder>()  {
    private lateinit var contexto : Context

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsuarioViewHolder {
        val vista_item=
            LayoutInflater.from(parent.context).inflate(R.layout.fila_usuario,parent, false)
        //Para poder hacer referencia al contexto de la aplicacion
        contexto=parent.context

        return UsuarioViewHolder(vista_item)
    }

    class UsuarioViewHolder(v: View):RecyclerView.ViewHolder(v){
        var imagen: ImageView =v.findViewById(R.id.fila_usuario_avatar)
        var nombre: TextView =v.findViewById(R.id.fila_usuario_nombre)
        var fecha: TextView =v.findViewById(R.id.fila_usuario_fechaCreacion)
        var contenedor:ConstraintLayout = v.findViewById(R.id.fila_usuario_todo)
    }


    override fun onBindViewHolder(holder: UsuarioViewHolder, position: Int) {
        val usuario_actual=lista_usuarios[position]

        holder.nombre.text=usuario_actual.nombre
        holder.fecha.text=usuario_actual.fecha.toString()
        //hay un error que no permite mostrar la imagen si su width o height nmo esta en wrap content
        Glide.with(contexto).load(usuario_actual.url_imagen).into(holder.imagen)

        holder.contenedor.setOnClickListener{
            if(usuario_actual.tipo=="normal") {
                val intent = Intent(contexto, ModificarUsuario::class.java)
                intent.putExtra("usuario", usuario_actual as Serializable)
                contexto.startActivity(intent)
            }else{
                Toast.makeText(contexto, "Este usuario es admin asi que no puedes modificar", Toast.LENGTH_SHORT).show()
            }
        }
/*
        if(usuario_actual.url_imagen!=null) {
            Glide.with(contexto).load(usuario_actual.url_imagen).into(holder.imagen)
        }else{
            holder.imagen.setImageResource(R.drawable.icons8_usuario_90)
        }

        holder.editar.setOnClickListener(View.OnClickListener {
            val actividad = Intent(contexto,EditarAvion::class.java)
            actividad.putExtra("AVION", avion_actual as Serializable)
            contexto.startActivity (actividad)
        })

        holder.borrar.setOnClickListener(View.OnClickListener {
            val db_ref= FirebaseDatabase.getInstance().getReference()
            val sto_ref= FirebaseStorage.getInstance().getReference()

            sto_ref.child("hangar").child("imagenes").child(usuario_actual.id!!).delete()
            db_ref.child("hangar").child("pilotos").child(usuario_actual.id!!).removeValue()

            Toast.makeText(contexto, "Usuario borrado con exito", Toast.LENGTH_SHORT).show()
        })*/

    }

    override fun getItemCount(): Int = lista_usuarios.size

}