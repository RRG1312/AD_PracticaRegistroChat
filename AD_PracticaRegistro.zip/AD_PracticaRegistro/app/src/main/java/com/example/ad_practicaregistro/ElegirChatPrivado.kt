package com.example.ad_practicaregistro

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class ElegirChatPrivado : AppCompatActivity() {

    lateinit var rv:RecyclerView
    lateinit var SP:SharedPreferences

    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference
    lateinit var pojo_usuario:Usuario

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_elegir_chat_privado)


    }

    override fun onStart() {
        super.onStart()
        val app_id = R.string.app_name
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)

        pojo_usuario=intent.getSerializableExtra("usuario") as Usuario

        var loged = SP.getString(
            R.string.sp_nombre_usuario.toString(),""
        )

        var tipo = SP.getString(
            R.string.sp_tipo_usuario.toString(),
            ""
        )


        var propioId= SP.getString(
            R.string.sp_id_usuario.toString(),
            ""
        )

        var lista = mutableListOf<Usuario>()

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        db_ref.child("hangar")
            .child("pilotos")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->
                        val pojo_usuario=hijo?.getValue(Usuario::class.java)
                        if(pojo_usuario?.id!=propioId && pojo_usuario?.estado!=0){
                            lista.add(pojo_usuario!!)
                        }
                    }
                    rv.adapter?.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })




        rv = findViewById(R.id.rv_usuariosDisponiblesChatPrivado)
        rv.adapter=AdaptadorUsuariosDisponibles(lista)
        rv.layoutManager= LinearLayoutManager(applicationContext)
        rv.setHasFixedSize(true)
    }


}